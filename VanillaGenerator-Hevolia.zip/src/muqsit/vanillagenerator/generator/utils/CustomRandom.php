<?php

namespace muqsit\vanillagenerator\generator\utils;

use pocketmine\utils\Random;

class CustomRandom extends Random
{

	private int $x;
	private int $y;
	private int $z;
	private int $w;

	protected int $seed;

	/**
	 * @param int $seed Integer to be used as seed.
	 */
	public function __construct(int $seed = -1)
	{
		if ($seed === -1) {
			$seed = time();
		}

		$this->setSeed($seed);
	}

	/**
	 * @param int $seed Integer to be used as seed.
	 */
	public function setSeed(int $seed): void
	{
		$this->seed = $seed;
		$this->x = self::X ^ $seed;
		$this->y = self::Y ^ ($seed << 17) | (($seed >> 15) & 0x7fffffff) & 0xffffffff;
		$this->z = self::Z ^ ($seed << 31) | (($seed >> 1) & 0x7fffffff) & 0xffffffff;
		$this->w = self::W ^ ($seed << 18) | (($seed >> 14) & 0x7fffffff) & 0xffffffff;
	}

	public function getSeed(): int
	{
		return $this->seed;
	}

	/**
	 * Returns an 31-bit integer (not signed)
	 */
	public function nextInt(): int
	{
		return $this->nextSignedInt() & 0x7fffffff;
	}

	/**
	 * Returns a float between 0.0 and 1.0 (inclusive)
	 */
	public function nextFloat(): float
	{
		return $this->nextInt() / 0x7fffffff;
	}

	/**
	 * Returns a float between -1.0 and 1.0 (inclusive)
	 */
	public function nextSignedFloat(): float
	{
		return $this->nextSignedInt() / 0x7fffffff;
	}

	/**
	 * Returns a random boolean
	 */
	public function nextBoolean(): bool
	{
		return ($this->nextSignedInt() & 0x01) === 0;
	}

	/**
	 * Returns a random integer between $start and $end
	 *
	 * @param int $start default 0
	 * @param int $end default 0x7fffffff
	 */
	public function nextRange(int $start = 0, int $end = 0x7fffffff): int
	{
		return $start + ($this->nextInt() % ($end + 1 - $start));
	}

	public function nextBoundedInt(int $bound): int
	{
		return $this->nextInt() % $bound;
	}


	/**
	 * Returns a 32-bit integer (signed)
	 */
	public function nextSignedInt(): int
	{
		$t = ($this->x ^ ($this->x << 11)) & 0xffffffff;

		$this->x = $this->y;
		$this->y = $this->z;
		$this->z = $this->w;

		$this->w = ($this->w ^ (($this->w >> 19) & 0x7fffffff) ^ ($t ^ (($t >> 8) & 0x7fffffff))) & 0xffffffff;
		return $this->w;
	}

	public function nextLong(): int
	{
		$bits1 = $this->nextInt() & 0xFFFFFFFF;
		$bits2 = $this->nextInt() & 0xFFFFFFFF;
		return ($bits1 << 32) | $bits2;
	}
}